export interface Student {
  id: string;
  name: string;
  present: boolean;
}

export interface User {
  username: string;
  password: string;
}

export interface AuthContextType {
  isAuthenticated: boolean;
  login: (username: string, password: string) => void;
  logout: () => void;
}

export interface CalendarStats {
  date: string;
  presentCount: number;
  absentCount: number;
  totalCount: number;
  courseDetails: CourseDetails;
}

export interface CourseDetails {
  courseName: string;
  chapter: string;
  type: 'TD' | 'TP' | 'COURSE';
  instructor: string;
}