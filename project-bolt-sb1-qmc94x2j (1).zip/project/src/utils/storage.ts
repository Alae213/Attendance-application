import { CalendarStats } from '../types';

const ATTENDANCE_STORAGE_KEY = 'attendance_stats';

export function getStoredAttendance(): CalendarStats[] {
  const stored = localStorage.getItem(ATTENDANCE_STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
}

export function storeAttendance(stats: CalendarStats[]): void {
  localStorage.setItem(ATTENDANCE_STORAGE_KEY, JSON.stringify(stats));
}