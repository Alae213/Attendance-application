import React, { useState } from 'react';
import { UserPlus } from 'lucide-react';
import { Student } from '../types';
import { Button } from './ui/Button';
import { StudentList } from './attendance/StudentList';
import { AttendanceSummary } from './attendance/AttendanceSummary';
import { AddStudentModal } from './attendance/AddStudentModal';
import { Navbar } from './navigation/Navbar';
import { CalendarPage } from './calendar/CalendarPage';
import { initialStudents } from '../data/students';
import { useAttendance } from '../hooks/useAttendance';

export default function AttendanceSystem() {
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [showAddModal, setShowAddModal] = useState(false);
  const [currentPage, setCurrentPage] = useState<'attendance' | 'calendar'>('attendance');
  const { updateAttendance } = useAttendance();
  const [date] = useState(new Date().toLocaleDateString());

  const toggleAttendance = (studentId: string) => {
    const updatedStudents = students.map(student =>
      student.id === studentId
        ? { ...student, present: !student.present }
        : student
    );
    setStudents(updatedStudents);
    updateAttendance(updatedStudents);
  };

  const handleAddStudent = (name: string) => {
    const newStudent: Student = {
      id: (students.length + 1).toString(),
      name,
      present: false,
    };
    const updatedStudents = [...students, newStudent];
    setStudents(updatedStudents);
    updateAttendance(updatedStudents);
  };

  const handleDeleteStudent = (studentId: string) => {
    const updatedStudents = students.filter(student => student.id !== studentId);
    setStudents(updatedStudents);
    updateAttendance(updatedStudents);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
      
      {currentPage === 'attendance' ? (
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-800">Attendance Sheet</h1>
                <p className="text-gray-600">Date: {date}</p>
              </div>
              <Button
                onClick={() => setShowAddModal(true)}
                variant="primary"
                icon={UserPlus}
              >
                Add Student
              </Button>
            </div>

            <StudentList 
              students={students}
              onToggleAttendance={toggleAttendance}
              onDeleteStudent={handleDeleteStudent}
            />

            <AttendanceSummary students={students} />
          </div>
        </div>
      ) : (
        <CalendarPage />
      )}

      {showAddModal && (
        <AddStudentModal
          onClose={() => setShowAddModal(false)}
          onAdd={handleAddStudent}
        />
      )}
    </div>
  );
}