import React from 'react';
import { Student } from '../../types';

interface AttendanceSummaryProps {
  students: Student[];
}

export function AttendanceSummary({ students }: AttendanceSummaryProps) {
  const presentCount = students.filter(s => s.present).length;
  const absentCount = students.length - presentCount;

  return (
    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
      <h2 className="text-lg font-semibold text-blue-800 mb-2">Summary</h2>
      <p className="text-blue-600">
        Present: {presentCount} | Absent: {absentCount} | Total: {students.length}
      </p>
    </div>
  );
}