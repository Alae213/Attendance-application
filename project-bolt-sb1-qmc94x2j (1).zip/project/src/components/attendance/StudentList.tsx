import React, { useState } from 'react';
import { CheckCircle, XCircle, Trash2 } from 'lucide-react';
import { Student } from '../../types';
import { Button } from '../ui/Button';
import { ConfirmationModal } from '../modals/ConfirmationModal';

interface StudentListProps {
  students: Student[];
  onToggleAttendance: (studentId: string) => void;
  onDeleteStudent: (studentId: string) => void;
}

export function StudentList({ students, onToggleAttendance, onDeleteStudent }: StudentListProps) {
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);

  const handleDeleteClick = (student: Student) => {
    setStudentToDelete(student);
  };

  const handleConfirmDelete = () => {
    if (studentToDelete) {
      onDeleteStudent(studentToDelete.id);
      setStudentToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      {students.map(student => (
        <div
          key={student.id}
          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition duration-200"
        >
          <span className="text-lg text-gray-800">{student.name}</span>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => onToggleAttendance(student.id)}
              variant={student.present ? 'success' : 'warning'}
              icon={student.present ? CheckCircle : XCircle}
            >
              {student.present ? 'Present' : 'Absent'}
            </Button>
            <Button
              onClick={() => handleDeleteClick(student)}
              variant="danger"
              icon={Trash2}
            >
              Delete
            </Button>
          </div>
        </div>
      ))}

      {studentToDelete && (
        <ConfirmationModal
          title="Delete Student"
          message={`Are you sure you want to delete ${studentToDelete.name}?`}
          onConfirm={handleConfirmDelete}
          onCancel={() => setStudentToDelete(null)}
        />
      )}
    </div>
  );
}