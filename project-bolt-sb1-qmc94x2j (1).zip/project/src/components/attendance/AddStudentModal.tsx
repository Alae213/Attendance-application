import React, { useState } from 'react';
import { X, UserPlus } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface AddStudentModalProps {
  onClose: () => void;
  onAdd: (name: string) => void;
}

export function AddStudentModal({ onClose, onAdd }: AddStudentModalProps) {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onAdd(name.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>

        <h2 className="text-xl font-semibold mb-4">Add New Student</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Student Name"
            icon={UserPlus}
            required
          />
          
          <div className="flex justify-end gap-2">
            <Button onClick={onClose} variant="warning">
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Add Student
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}