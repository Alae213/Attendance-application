import React from 'react';
import { Users, Calendar, LogOut } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../context/AuthContext';

interface NavbarProps {
  onNavigate: (page: 'attendance' | 'calendar') => void;
  currentPage: 'attendance' | 'calendar';
}

export function Navbar({ onNavigate, currentPage }: NavbarProps) {
  const { logout } = useAuth();

  return (
    <nav className="bg-white shadow-md mb-6">
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => onNavigate('attendance')}
              variant={currentPage === 'attendance' ? 'primary' : 'warning'}
              icon={Users}
            >
              Attendance
            </Button>
            <Button
              onClick={() => onNavigate('calendar')}
              variant={currentPage === 'calendar' ? 'primary' : 'warning'}
              icon={Calendar}
            >
              Calendar
            </Button>
          </div>
          <Button onClick={logout} variant="danger" icon={LogOut}>
            Logout
          </Button>
        </div>
      </div>
    </nav>
  );
}