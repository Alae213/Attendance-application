import React, { useState } from 'react';
import { Calendar, PlusCircle } from 'lucide-react';
import { useAttendance } from '../../hooks/useAttendance';
import { Button } from '../ui/Button';
import { AddDayModal } from './AddDayModal';
import { CalendarGrid } from './CalendarGrid';

export function CalendarPage() {
  const { attendanceStats, addDay, updateCourseDetails } = useAttendance();
  const [showAddModal, setShowAddModal] = useState(false);

  return (
    <div className="p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Calendar className="text-blue-600" size={24} />
            <h1 className="text-2xl font-bold text-gray-800">Course Calendar</h1>
          </div>
          <Button
            onClick={() => setShowAddModal(true)}
            variant="primary"
            icon={PlusCircle}
          >
            Add Day
          </Button>
        </div>

        <CalendarGrid 
          attendanceStats={attendanceStats} 
          onUpdateDay={updateCourseDetails}
        />

        {showAddModal && (
          <AddDayModal
            onClose={() => setShowAddModal(false)}
            onAdd={addDay}
          />
        )}
      </div>
    </div>
  );
}