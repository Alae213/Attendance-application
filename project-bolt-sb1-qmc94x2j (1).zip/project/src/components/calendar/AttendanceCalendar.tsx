import React from 'react';
import { CalendarStats } from '../../types';
import { formatDate } from '../../utils/dateUtils';

interface AttendanceCalendarProps {
  attendanceStats: CalendarStats[];
}

export function AttendanceCalendar({ attendanceStats }: AttendanceCalendarProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Attendance Calendar</h2>
      <div className="space-y-4">
        {attendanceStats.map((stat) => (
          <div
            key={stat.date}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div>
              <h3 className="font-medium text-gray-800">{formatDate(stat.date)}</h3>
              <p className="text-sm text-gray-600">
                Present: {stat.presentCount} | Absent: {stat.absentCount} | Total: {stat.totalCount}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-24 bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-500 rounded-full h-2"
                  style={{
                    width: `${(stat.presentCount / stat.totalCount) * 100}%`,
                  }}
                />
              </div>
              <span className="text-sm text-gray-600">
                {Math.round((stat.presentCount / stat.totalCount) * 100)}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}