import React, { useState } from 'react';
import { X, Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { CourseDetails } from '../../types';

interface AddDayModalProps {
  onClose: () => void;
  onAdd: (date: string, courseDetails: CourseDetails) => void;
}

export function AddDayModal({ onClose, onAdd }: AddDayModalProps) {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [courseDetails, setCourseDetails] = useState<CourseDetails>({
    courseName: '',
    chapter: '',
    type: 'COURSE',
    instructor: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (courseDetails.courseName && courseDetails.chapter) {
      onAdd(date, courseDetails);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>

        <h2 className="text-xl font-semibold mb-4">Add New Day</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              icon={CalendarIcon}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Course Name
            </label>
            <Input
              type="text"
              value={courseDetails.courseName}
              onChange={(e) => setCourseDetails({
                ...courseDetails,
                courseName: e.target.value
              })}
              placeholder="e.g., Mathematics"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Chapter
            </label>
            <Input
              type="text"
              value={courseDetails.chapter}
              onChange={(e) => setCourseDetails({
                ...courseDetails,
                chapter: e.target.value
              })}
              placeholder="e.g., Chapter 1: Introduction"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type
            </label>
            <select
              value={courseDetails.type}
              onChange={(e) => setCourseDetails({
                ...courseDetails,
                type: e.target.value as CourseDetails['type']
              })}
              className="w-full rounded-lg border border-gray-300 p-2"
            >
              <option value="COURSE">Course</option>
              <option value="TD">TD</option>
              <option value="TP">TP</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Instructor
            </label>
            <Input
              type="text"
              value={courseDetails.instructor}
              onChange={(e) => setCourseDetails({
                ...courseDetails,
                instructor: e.target.value
              })}
              placeholder="Instructor name"
              required
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button onClick={onClose} variant="warning">
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Add Day
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}