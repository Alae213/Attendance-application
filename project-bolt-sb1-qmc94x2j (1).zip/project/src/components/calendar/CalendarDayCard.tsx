import React, { useState } from 'react';
import { Edit2, Save, X } from 'lucide-react';
import { CalendarStats } from '../../types';
import { formatDate } from '../../utils/dateUtils';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface CalendarDayCardProps {
  stat: CalendarStats;
  onUpdate: (date: string, updates: Partial<CalendarStats['courseDetails']>) => void;
}

export function CalendarDayCard({ stat, onUpdate }: CalendarDayCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedDetails, setEditedDetails] = useState(stat.courseDetails);

  const handleSave = () => {
    onUpdate(stat.date, editedDetails);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedDetails(stat.courseDetails);
    setIsEditing(false);
  };

  return (
    <div className="bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
      <div className="border-b pb-2 mb-2">
        <div className="flex justify-between items-start">
          <h3 className="font-medium text-gray-800">{formatDate(stat.date)}</h3>
          {!isEditing ? (
            <Button
              onClick={() => setIsEditing(true)}
              variant="warning"
              icon={Edit2}
              className="!p-2"
            >
              Edit
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button
                onClick={handleSave}
                variant="success"
                icon={Save}
                className="!p-2"
              >
                Save
              </Button>
              <Button
                onClick={handleCancel}
                variant="warning"
                icon={X}
                className="!p-2"
              >
                Cancel
              </Button>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 mt-1">
          <span className={`px-2 py-1 text-xs rounded ${
            stat.courseDetails.type === 'TD' ? 'bg-blue-100 text-blue-800' :
            stat.courseDetails.type === 'TP' ? 'bg-green-100 text-green-800' :
            'bg-purple-100 text-purple-800'
          }`}>
            {stat.courseDetails.type}
          </span>
          {isEditing ? (
            <select
              value={editedDetails.type}
              onChange={(e) => setEditedDetails({
                ...editedDetails,
                type: e.target.value as CalendarStats['courseDetails']['type']
              })}
              className="text-sm border rounded px-2 py-1"
            >
              <option value="COURSE">Course</option>
              <option value="TD">TD</option>
              <option value="TP">TP</option>
            </select>
          ) : (
            <span className="text-sm text-gray-600">{stat.courseDetails.instructor}</span>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {isEditing ? (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Course Name
              </label>
              <Input
                type="text"
                value={editedDetails.courseName}
                onChange={(e) => setEditedDetails({
                  ...editedDetails,
                  courseName: e.target.value
                })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Chapter
              </label>
              <Input
                type="text"
                value={editedDetails.chapter}
                onChange={(e) => setEditedDetails({
                  ...editedDetails,
                  chapter: e.target.value
                })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Instructor
              </label>
              <Input
                type="text"
                value={editedDetails.instructor}
                onChange={(e) => setEditedDetails({
                  ...editedDetails,
                  instructor: e.target.value
                })}
              />
            </div>
          </>
        ) : (
          <>
            <div>
              <h4 className="text-sm font-medium text-gray-700">Course</h4>
              <p className="text-gray-800">{stat.courseDetails.courseName}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700">Chapter</h4>
              <p className="text-gray-800">{stat.courseDetails.chapter}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-700">Instructor</h4>
              <p className="text-gray-800">{stat.courseDetails.instructor}</p>
            </div>
          </>
        )}
      </div>

      <div className="mt-4">
        <div className="flex justify-between text-sm text-gray-600">
          <span>Present: {stat.presentCount}</span>
          <span>Absent: {stat.absentCount}</span>
        </div>
      </div>
    </div>
  );
}