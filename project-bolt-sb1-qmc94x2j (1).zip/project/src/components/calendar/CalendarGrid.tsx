import React from 'react';
import { CalendarStats } from '../../types';
import { CalendarDayCard } from './CalendarDayCard';

interface CalendarGridProps {
  attendanceStats: CalendarStats[];
  onUpdateDay: (date: string, updates: Partial<CalendarStats['courseDetails']>) => void;
}

export function CalendarGrid({ attendanceStats, onUpdateDay }: CalendarGridProps) {
  const sortedStats = [...attendanceStats].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {sortedStats.map((stat) => (
        <CalendarDayCard 
          key={stat.date} 
          stat={stat} 
          onUpdate={onUpdateDay}
        />
      ))}
    </div>
  );
}