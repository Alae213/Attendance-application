import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { Button } from '../ui/Button';

interface ConfirmationModalProps {
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmationModal({
  title,
  message,
  onConfirm,
  onCancel
}: ConfirmationModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md relative">
        <button
          onClick={onCancel}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="text-yellow-500" size={24} />
          <h2 className="text-xl font-semibold text-gray-800">{title}</h2>
        </div>
        
        <p className="text-gray-600 mb-6">{message}</p>

        <div className="flex justify-end gap-2">
          <Button onClick={onCancel} variant="warning">
            Cancel
          </Button>
          <Button onClick={onConfirm} variant="danger">
            Confirm
          </Button>
        </div>
      </div>
    </div>
  );
}