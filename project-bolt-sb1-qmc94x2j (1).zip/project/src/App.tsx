import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './components/LoginPage';
import AttendanceSystem from './components/AttendanceSystem';

function AppContent() {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <AttendanceSystem /> : <LoginPage />;
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;