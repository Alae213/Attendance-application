import { useState, useEffect } from 'react';
import { Student, CalendarStats, CourseDetails } from '../types';
import { getStoredAttendance, storeAttendance } from '../utils/storage';

export function useAttendance() {
  const [attendanceStats, setAttendanceStats] = useState<CalendarStats[]>([]);

  useEffect(() => {
    const stats = getStoredAttendance();
    setAttendanceStats(stats);
  }, []);

  const updateAttendance = (students: Student[]) => {
    const today = new Date().toISOString().split('T')[0];
    const presentCount = students.filter(s => s.present).length;
    const totalCount = students.length;

    const existingStat = attendanceStats.find(stat => stat.date === today);
    const newStat: CalendarStats = {
      date: today,
      presentCount,
      absentCount: totalCount - presentCount,
      totalCount,
      courseDetails: existingStat?.courseDetails || {
        courseName: '',
        chapter: '',
        type: 'COURSE',
        instructor: ''
      }
    };

    const updatedStats = [
      newStat,
      ...attendanceStats.filter(stat => stat.date !== today)
    ];

    setAttendanceStats(updatedStats);
    storeAttendance(updatedStats);
  };

  const addDay = (date: string, courseDetails: CourseDetails) => {
    const existingStat = attendanceStats.find(stat => stat.date === date);
    const newStat: CalendarStats = {
      date,
      presentCount: existingStat?.presentCount || 0,
      absentCount: existingStat?.absentCount || 0,
      totalCount: existingStat?.totalCount || 0,
      courseDetails
    };

    const updatedStats = [
      newStat,
      ...attendanceStats.filter(stat => stat.date !== date)
    ];

    setAttendanceStats(updatedStats);
    storeAttendance(updatedStats);
  };

  const updateCourseDetails = (date: string, updates: Partial<CourseDetails>) => {
    const updatedStats = attendanceStats.map(stat => {
      if (stat.date === date) {
        return {
          ...stat,
          courseDetails: {
            ...stat.courseDetails,
            ...updates
          }
        };
      }
      return stat;
    });

    setAttendanceStats(updatedStats);
    storeAttendance(updatedStats);
  };

  return { attendanceStats, updateAttendance, addDay, updateCourseDetails };
}