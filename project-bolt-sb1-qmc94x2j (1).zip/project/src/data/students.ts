import { Student } from '../types';

export const initialStudents: Student[] = [
  { id: '1', name: 'John Doe', present: false },
  { id: '2', name: 'Jane Smith', present: false },
  { id: '3', name: 'Mike Johnson', present: false },
  { id: '4', name: 'Sarah Williams', present: false },
  { id: '5', name: 'Tom Brown', present: false },
];